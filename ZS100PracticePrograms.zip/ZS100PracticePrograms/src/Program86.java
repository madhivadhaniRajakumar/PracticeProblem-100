import java.util.Arrays;

public class Program86 {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		char[] JavaCharArray = {'a', 'b', 'c', 'd', 'e'};  
//        for (int i=0; i<JavaCharArray.length; i++) {  
//        System.out.println(JavaCharArray[i]);  
//        }  
//
//	}
	
	public static void main(String[] args) {
		  char[] JavaCharArray = {'e', 'b', 'c', 'a', 'd'};  
	      //  Arrays.sort(JavaCharArray);  
	        System.out.println(Arrays.toString(JavaCharArray));  
	}

}
