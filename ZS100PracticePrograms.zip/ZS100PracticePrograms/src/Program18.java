
public class Program18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=20;
		int b=10;
		//System.out.println(++a);
		//System.out.println(b++);
	//	System.out.println(++a-b--);
		//System.out.println(a%b++);
		System.out.println(a*=b+5);

		int x;
		System.out.println(x=69>>>2);

	}

}
