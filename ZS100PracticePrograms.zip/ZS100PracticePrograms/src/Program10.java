
public class Program10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] a = {1,2,3,4,5,6,7};
		int len = a.length;
		
		int temp;
		for(int pos=0;pos<len;pos=pos+2) {
			temp=a[len-1];
			for(int i=len-1;i>pos;i--) {
				a[i]=a[i-1];
				
			}
			a[pos]=temp;
		}
		for(int i=0;i<len;i++) {
			System.out.print(a[i]+" ");
		}
	
	}
	

}
