
public class Program99 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char c = 'B';
		char ch = (char) (c+32);
		System.out.println(ch);

	}

}
