
public class Program100 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ascii = 69;
		char c = (char) ascii;
		System.out.println(c);
		

	}
	
	
}
