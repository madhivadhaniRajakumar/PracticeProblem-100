import java.util.ArrayList;
import java.util.List;

public class sample {

	public static void main(String[] args) {
		int[]numbers = new int[]{2,3,5,7,11,15};
		int target =9;
		int n = numbers.length;
        int k=0;
        int [] arr = new int[]{-1,-1};
        while(k<n){
            if(numbers[k]<target){
                k++;
            }
            else{
                break;
            }
        }
        for(int i=0;i<k;i++){
            int j=i;
            while(j<k){
                if(numbers[j]+numbers[k]==target){
                    arr[0]=j;
                    arr[1]=k;
                   
                }
                j++;
            }
             
        }
     

	}
		
	}


