
public class Program26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long num1=1099999999999999999L;  
		long num2=-10L;  
		System.out.println("num1: "+num1);  
		System.out.println("num2: "+num2); 
	}

}
