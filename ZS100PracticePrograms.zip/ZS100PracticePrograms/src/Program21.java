
public class Program21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int y=10;
		int z;
		z=(++y *(y++ +5));
		System.out.println(z);
	}

}
