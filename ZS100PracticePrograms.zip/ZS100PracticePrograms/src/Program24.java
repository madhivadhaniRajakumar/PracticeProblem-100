import java.util.Scanner;

public class Program24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char ch;
		Scanner sc = new Scanner(System.in);
		ch = sc.next().charAt(0);
		
		int asc = ch;
		System.out.println(asc);
	}

}
