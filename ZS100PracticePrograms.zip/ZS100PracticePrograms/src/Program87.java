
public class Program87 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char[] arr = { 'g', 'e', 'e', 'k', 's', 'f', 'o',
                'r', 'g', 'e', 'e', 'k', 's' };


	 String str = String.copyValueOf(arr);
	 System.out.print(str);

	}

}
