
public class Program22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x= 5;
//System.out.println(++x);
//System.out.println(x++);
//System.out.println(--x);
int x1; 
x1= ++x-x++ + --x;
System.out.println(x1);
	}

}
