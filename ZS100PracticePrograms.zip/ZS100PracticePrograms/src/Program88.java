
public class Program88 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "Scaler";
		char[] arr = str.toCharArray();
		for (char x : arr)
		{
			System.out.println(x);
		}

	}

}
