

public class Program63 {
/*APPROACH 1
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []a = new int [] {3,4,7,1,2,9,0,-2,89};
		int n = a.length;
		int max=0;
		int min = a[0];
		for(int i=0;i<n;i++) {
			if(a[i]>max) {
				max = a[i];
			}
			if(a[i]<min) {
				min = a[i];
			}
		}
		System.out.println(max);
		System.out.println(min);

	}
	*/
	
	//APPROACH 2
	
	public static void main(String[] args) {
		int []a = new int [] {3,4,7,1,2,9,0,-2,89};
		int n = a.length;
		int temp;
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				if(a[i]>a[j]) {
					temp =a[j];
					a[j]=a[i];
					a[i]=temp;
				}
			}
		}
		System.out.println(a[0]);
		System.out.println(a[n-1]);
	}

}
